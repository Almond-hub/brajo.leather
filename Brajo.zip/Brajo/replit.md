# Brajo Leather Watch Bracelets Website

## Overview

This is a full-stack web application built for Brajo, a luxury leather watch bracelet company with Moroccan heritage. The application features a modern, elegant showcase website with a contact form, built using React and Express with TypeScript. The design emphasizes the brand's craftsmanship heritage while maintaining a contemporary professional appearance.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: 
  - Tailwind CSS for utility-first styling
  - Custom color scheme reflecting leather/Moroccan themes
  - Professional design system with radius configuration
- **UI Components**: Extensive use of Radix UI primitives with custom theming
- **State Management**: React Query for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Development**: TSX for TypeScript execution in development
- **Production Build**: ESBuild for server bundling

### Database Integration
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured via Neon serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Current Implementation**: Memory storage interface with planned database integration

## Key Components

### Frontend Components
1. **Page Sections**:
   - Hero section with 3D canvas background
   - About section with company story
   - History timeline section
   - Product showcase with filtering
   - Craftsmanship process display
   - Contact form with validation

2. **Interactive Elements**:
   - Smooth scrolling navigation
   - Animated section reveals on scroll
   - Product category filtering
   - 3D particle effects using Three.js
   - Responsive mobile navigation

3. **UI System**:
   - Complete design system using shadcn/ui components
   - Toast notifications for user feedback
   - Form validation with React Hook Form
   - Accessible components following ARIA standards

### Backend Components
1. **API Routes**:
   - Contact form submission endpoint (`POST /api/contact`)
   - Form validation and response handling
   - Structured error handling middleware

2. **Storage Layer**:
   - Abstract storage interface for future database integration
   - Memory storage implementation for development
   - User management schema prepared for authentication

3. **Development Tools**:
   - Hot module replacement in development
   - Request logging middleware
   - Error overlay for development debugging

## Data Flow

1. **Client Interaction**: User interacts with the React frontend
2. **State Management**: React Query manages API calls and caching
3. **API Communication**: RESTful API calls to Express backend
4. **Data Processing**: Express routes handle business logic
5. **Storage**: Currently memory-based, prepared for PostgreSQL integration
6. **Response**: JSON responses with proper error handling
7. **UI Updates**: React components update based on API responses

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React ecosystem with hooks and context
- **Styling**: Tailwind CSS with PostCSS processing
- **Components**: Radix UI primitives for accessible components
- **3D Graphics**: Three.js for interactive background effects
- **Forms**: React Hook Form with Zod validation
- **Date Handling**: date-fns for timestamp formatting
- **Utilities**: clsx for conditional classes, nanoid for unique IDs

### Backend Dependencies
- **Server**: Express.js with middleware support
- **Database**: Drizzle ORM with PostgreSQL support
- **Session Management**: connect-pg-simple for PostgreSQL sessions
- **Development**: TSX for TypeScript execution
- **Build**: ESBuild for production bundling

### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit environment
- **Error Handling**: Runtime error modal for development
- **Code Quality**: TypeScript strict mode configuration
- **Security**: Semgrep rules for security scanning

## Deployment Strategy

### Development Environment
- **Hot Reloading**: Vite dev server with HMR
- **TypeScript**: Real-time type checking
- **Development Server**: Express with Vite middleware integration
- **Asset Serving**: Vite handles static assets and bundling

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild bundles Node.js server to `dist/index.js`
- **Static Assets**: Served directly from Express in production
- **Environment**: NODE_ENV=production switches to production mode

### Database Configuration
- **Environment Variables**: DATABASE_URL for PostgreSQL connection
- **Migration System**: Drizzle Kit for schema changes
- **Connection**: Neon serverless for PostgreSQL hosting
- **Session Storage**: PostgreSQL-backed sessions for scalability

## Changelog

Changelog:
- June 30, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.