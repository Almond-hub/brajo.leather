import { useState } from "react";
import { PRODUCTS } from "@/lib/constants";
import { SectionFadeIn } from "./SectionFadeIn";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ChevronRight } from "lucide-react";

type ProductCategory = "all" | "classic" | "modern" | "heritage" | "bespoke";

export function ProductsSection() {
  const [activeCategory, setActiveCategory] = useState<ProductCategory>("all");

  const categories: { id: ProductCategory; label: string }[] = [
    { id: "all", label: "All Collections" },
    { id: "classic", label: "Classic" },
    { id: "modern", label: "Modern" },
    { id: "heritage", label: "Heritage" },
    { id: "bespoke", label: "Bespoke" },
  ];

  return (
    <section id="products" className="py-12 sm:py-16 lg:py-24 bg-gradient-to-br from-[#FAEBD7] to-[#F5DEB3]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <SectionFadeIn>
            <div className="text-center mb-12 sm:mb-16 lg:mb-20">
              <h2 className="font-serif text-2xl sm:text-3xl md:text-5xl font-bold mb-4 sm:mb-6">
                Our Collections
              </h2>
              <div className="w-16 sm:w-24 h-1 bg-[#D4AF37] mx-auto"></div>
              <p className="mt-4 sm:mt-6 max-w-2xl mx-auto text-gray-600 text-sm sm:text-base px-4">
                Discover our exquisite range of handcrafted leather watch bracelets,
                each piece a testament to uncompromising quality and artisanship
              </p>
            </div>
          </SectionFadeIn>

          {/* Product Categories */}
          <SectionFadeIn>
            <div className="flex justify-center mb-8 sm:mb-12 overflow-x-auto pb-4 px-4">
              <div className="flex space-x-2 sm:space-x-4 md:space-x-6 font-sans text-xs sm:text-sm whitespace-nowrap">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={cn(
                      "py-2 px-3 sm:px-4 md:px-6 rounded-full transition duration-300 focus:outline-none text-xs sm:text-sm",
                      activeCategory === category.id
                        ? "bg-[#5D4037] text-white"
                        : "hover:bg-[#5D4037] hover:text-white border border-[#5D4037] text-[#5D4037]"
                    )}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
            </div>
          </SectionFadeIn>

          {/* Product Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PRODUCTS.map((product, index) => (
              <SectionFadeIn key={product.id} delay={index * 100}>
                <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-all duration-400 hover:translate-y-[-10px] hover:shadow-xl">
                  <div className="h-64 relative overflow-hidden">
                    <img 
                      src="https://i.imgur.com/57U3v5O.jpeg" 
                      alt={`${product.name} - Brajo leather watch bracelet`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-serif text-xl font-bold">{product.name}</h3>
                      <span className="text-[#D4AF37] font-sans">{product.price}</span>
                    </div>
                    <p className="text-gray-600 mb-6">
                      {product.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div>
                        {product.customizable ? (
                          <span className="text-xs text-gray-500">Customizable</span>
                        ) : (
                          <>
                            <span className="text-xs text-gray-500">Available in:</span>
                            <div className="flex mt-1 space-x-2">
                              {product.colors?.map((color, colorIndex) => (
                                <div 
                                  key={colorIndex} 
                                  className={`w-4 h-4 rounded-full ${color.color} border border-white`}
                                  title={color.name}
                                ></div>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                      <button className="text-[#5D4037] hover:text-[#D4AF37] transition-colors focus:outline-none">
                        <ChevronRight className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </SectionFadeIn>
            ))}
          </div>

          <div className="text-center mt-16">
            <Button className="bg-[#5D4037] hover:bg-[#3E2723] text-white font-medium py-3 px-8 text-sm tracking-wide">
              VIEW ALL COLLECTIONS
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
