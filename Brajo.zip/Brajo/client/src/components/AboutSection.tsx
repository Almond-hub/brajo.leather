import { TEAM } from "@/lib/constants";
import { SectionFadeIn } from "./SectionFadeIn";

export function AboutSection() {
  return (
    <section id="about" className="py-12 sm:py-16 lg:py-24 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <SectionFadeIn>
            <div className="text-center mb-12 sm:mb-16 lg:mb-20">
              <h2 className="font-serif text-2xl sm:text-3xl md:text-5xl font-bold mb-4 sm:mb-6">
                The Brajo Story
              </h2>
              <div className="w-16 sm:w-24 h-1 bg-[#D4AF37] mx-auto"></div>
            </div>
          </SectionFadeIn>

          <div className="grid md:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-center">
            <SectionFadeIn direction="left">
              <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://i.imgur.com/MadV1OG.png" 
                  alt="Brajo leather craftsmanship workshop"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
            </SectionFadeIn>

            <SectionFadeIn direction="right">
              <h3 className="font-serif text-2xl md:text-3xl font-semibold mb-6 text-[#5D4037]">
                A Legacy of Excellence
              </h3>
              <p className="mb-6 text-gray-700">
                Founded over two decades ago in Morocco by master craftsman
                Abdelah, Brajo has established itself as a premier creator of
                luxury leather watch bracelets. Our journey began in a small
                workshop in the ancient city of Fez, where traditional
                techniques were passed down through generations.
              </p>
              <p className="mb-8 text-gray-700">
                Today, under the leadership of Abdelah's sons, Said and
                Mustapha, we continue to honor our heritage while embracing
                innovation. Each Brajo creation reflects our commitment to
                quality, attention to detail, and respect for Morocco's rich
                leather-working tradition.
              </p>
              <div className="flex items-center">
                <div className="w-16 h-1 bg-[#D4AF37]"></div>
                <p className="ml-4 text-[#5D4037] italic font-serif">
                  "The art of time, wrapped in tradition."
                </p>
              </div>
            </SectionFadeIn>
          </div>

          {/* Founders Section */}
          <div className="mt-16 sm:mt-24 lg:mt-32">
            <SectionFadeIn>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-center mb-8 sm:mb-12 lg:mb-16">
                Our Leadership
              </h3>
            </SectionFadeIn>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {TEAM.map((member, index) => {
                // Define image URLs for each team member
                const getImageUrl = (memberName: string) => {
                  switch (memberName.toLowerCase()) {
                    case 'abdelah':
                      return 'https://i.imgur.com/qScHbdJ.jpeg';
                    case 'said':
                      return 'https://i.imgur.com/JDDxenN.jpeg';
                    case 'mustapha':
                      return 'https://i.imgur.com/ceZXRJm.jpeg';
                    default:
                      return '';
                  }
                };

                return (
                  <SectionFadeIn key={member.id} delay={index * 200}>
                    <div className="bg-white rounded-lg overflow-hidden shadow-lg transform transition-all hover:translate-y-[-5px] hover:shadow-xl duration-300">
                      <div className="h-80 relative overflow-hidden">
                        <img 
                          src={getImageUrl(member.name)}
                          alt={`${member.name} - ${member.role}`}
                          className="w-full h-full object-cover object-top"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                      </div>
                      <div className="p-6">
                        <h4 className="font-serif text-xl font-bold mb-2">
                          {member.name}
                        </h4>
                        <p className="text-[#D4AF37] font-medium mb-4 text-sm">
                          {member.role}
                        </p>
                        <p className="text-gray-600">
                          {member.description}
                        </p>
                      </div>
                    </div>
                  </SectionFadeIn>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="absolute inset-0 bg-gradient-to-b from-[#F5F5DC] to-[#FAEBD7] opacity-30 -z-10"></div>
    </section>
  );
}
