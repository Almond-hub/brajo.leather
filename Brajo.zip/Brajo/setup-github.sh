#!/bin/bash

# Setup script for GitHub deployment of Brajo Leather website

echo "🚀 Setting up Brajo Leather for GitHub deployment..."

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "📁 Initializing Git repository..."
    git init
    git branch -M main
else
    echo "✅ Git repository already initialized"
fi

# Add all files to git
echo "📝 Adding files to Git..."
git add .

# Create initial commit
echo "💾 Creating initial commit..."
git commit -m "Initial commit: Brajo Leather website with 3D animations and responsive design

- Modern React frontend with TypeScript
- Express backend with contact form handling
- 3D Three.js background animations
- Responsive design with Tailwind CSS
- Product showcase with filtering
- Company history timeline
- Professional contact form
- Security vulnerability patched (Vite CVE-2025-30208)"

echo "✅ Repository ready for GitHub!"
echo ""
echo "📋 Next steps:"
echo "1. Create a new repository on GitHub.com"
echo "2. Run these commands to push your code:"
echo "   git remote add origin https://github.com/YOUR_USERNAME/brajo-leather.git"
echo "   git push -u origin main"
echo ""
echo "3. Enable GitHub Pages in repository settings"
echo "4. Or deploy to Vercel/Netlify for full functionality"
echo ""
echo "📖 See DEPLOYMENT.md for detailed deployment instructions"