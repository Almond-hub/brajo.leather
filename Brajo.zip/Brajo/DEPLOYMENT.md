# Deployment Guide for Brajo Leather Website

This guide covers different deployment options for your Brajo leather website.

## Option 1: GitHub Pages (Static Frontend Only)

**Best for**: Showcasing the website design and frontend functionality
**Limitations**: Contact form won't work (no backend)

### Setup Steps:

1. **Push to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/brajo-leather.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**:
   - Go to your GitHub repository
   - Click "Settings" tab
   - Scroll to "Pages" section
   - Select "GitHub Actions" as source
   - The workflow will automatically deploy on push to main

3. **Your site will be available at**: `https://yourusername.github.io/brajo-leather`

## Option 2: Vercel (Recommended for Full-Stack)

**Best for**: Complete functionality including contact form
**Cost**: Free tier available

### Setup Steps:

1. **Push to GitHub** (same as above)

2. **Deploy to Vercel**:
   - Go to [vercel.com](https://vercel.com)
   - Sign up with GitHub
   - Click "New Project"
   - Select your repository
   - Configure build settings:
     - Build Command: `npm run build`
     - Output Directory: `dist/public`
     - Install Command: `npm install`

3. **Add Environment Variables** (if using database):
   - In Vercel dashboard, go to Settings → Environment Variables
   - Add `DATABASE_URL` if needed

## Option 3: Netlify

**Best for**: Easy deployment with form handling
**Cost**: Free tier available

### Setup Steps:

1. **Push to GitHub** (same as above)

2. **Deploy to Netlify**:
   - Go to [netlify.com](https://netlify.com)
   - Sign up with GitHub
   - Click "New site from Git"
   - Select your repository
   - Configure build settings:
     - Build command: `npm run build`
     - Publish directory: `dist/public`

3. **Form Handling**: Netlify can handle your contact form automatically

## Option 4: Railway (For Database Integration)

**Best for**: Full-stack with PostgreSQL database
**Cost**: Pay-as-you-use

### Setup Steps:

1. **Push to GitHub** (same as above)

2. **Deploy to Railway**:
   - Go to [railway.app](https://railway.app)
   - Sign up with GitHub
   - Click "Deploy from GitHub repo"
   - Select your repository
   - Add PostgreSQL database service

3. **Environment Variables**: Automatically configured

## Option 5: Render

**Best for**: Simple full-stack deployment
**Cost**: Free tier available (with limitations)

### Setup Steps:

1. **Push to GitHub** (same as above)

2. **Deploy to Render**:
   - Go to [render.com](https://render.com)
   - Sign up with GitHub
   - Click "New Web Service"
   - Connect your repository
   - Configure:
     - Build Command: `npm run build`
     - Start Command: `npm start`

## Recommended Approach

For your Brajo leather website, I recommend **Vercel** because:
- Easy setup with GitHub integration
- Excellent performance for React applications
- Built-in contact form handling
- Custom domain support
- Free tier is generous

## Next Steps

1. Choose your preferred deployment platform
2. Create a GitHub repository
3. Push your code using the commands above
4. Follow the platform-specific setup steps

Would you like me to help you set up any specific deployment option?