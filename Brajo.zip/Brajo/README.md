# Brajo Leather Watch Bracelets

A modern, elegant website showcasing Brajo's luxury leather watch bracelets with over 20 years of Moroccan craftsmanship heritage.

## Features

- **Elegant Design**: Modern, responsive design with Moroccan-inspired color scheme
- **3D Interactive Elements**: Three.js powered background animations
- **Smooth Animations**: Scroll-triggered animations and transitions
- **Product Showcase**: Filterable product gallery with detailed descriptions
- **Company Heritage**: Timeline showcasing 20+ years of craftsmanship
- **Contact Form**: Professional contact form with validation
- **Mobile Responsive**: Optimized for all device sizes

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Three.js** for 3D effects
- **Framer Motion** for animations
- **React Hook Form** with Zod validation
- **Radix UI** components

### Backend
- **Node.js** with Express
- **TypeScript** with ES modules
- **Drizzle ORM** for database operations
- **PostgreSQL** database support

### Build Tools
- **Vite** for fast development and optimized builds
- **ESBuild** for production server bundling

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/brajo-leather.git
cd brajo-leather
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

### Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── lib/           # Utilities and hooks
│   │   └── main.tsx       # Application entry point
├── server/                # Backend Express server
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   └── storage.ts        # Data storage layer
├── shared/               # Shared types and schemas
└── dist/                # Production build output
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run check` - Type checking
- `npm run db:push` - Push database schema changes

## Deployment

This application is ready for deployment on various platforms:

- **Vercel/Netlify**: For static deployment (frontend only)
- **Railway/Render**: For full-stack deployment
- **Docker**: Container-ready setup available

## Environment Variables

For database integration, set:
- `DATABASE_URL` - PostgreSQL connection string

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

For questions about Brajo products or this website, please use the contact form on the website.